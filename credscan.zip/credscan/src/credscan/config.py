"""Config loader. Reads TOML from ~/.config/credscan/config.toml by default."""
from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import Any

DEFAULT_CONFIG_DIR = Path(
    os.environ.get("CREDSCAN_CONFIG_DIR", str(Path.home() / ".config" / "credscan"))
)
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.toml"
DEFAULT_DB_PATH = DEFAULT_CONFIG_DIR / "findings.db"


def load_config(path: Path | None = None) -> dict[str, Any]:
    """Return config dict. Missing file is not an error."""
    p = path or DEFAULT_CONFIG_PATH
    if not p.exists():
        return {}
    with open(p, "rb") as f:
        return tomllib.load(f)


def scanner_config(name: str, config: dict[str, Any]) -> dict[str, Any]:
    scanners = config.get("scanners", {})
    return scanners.get(name, {}) or {}
