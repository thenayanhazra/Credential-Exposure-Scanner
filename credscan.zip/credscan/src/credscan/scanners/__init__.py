"""Scanner implementations. Each module provides one Scanner subclass."""
