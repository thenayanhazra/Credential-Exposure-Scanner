"""credscan: credential exposure scanner."""

__version__ = "0.1.0"
